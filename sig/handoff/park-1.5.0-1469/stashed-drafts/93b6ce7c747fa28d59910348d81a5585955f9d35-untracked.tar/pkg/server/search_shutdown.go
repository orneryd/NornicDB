package server

import (
    "net/http"
    "github.com/orneryd/nornicdb/pkg/nornicdb"
)

// Shutdown is service unavailability, never a successful BM25-only fallback.
// Use the same status and boundary identity as other unavailable routes.
func(s *Server) writeSearchShutdown(w http.ResponseWriter,r *http.Request) bool {
    if !s.db.GetCypherExecutor().QueryEmbedderBinding().IsClosing(){return false}
    s.writeBoundaryError(w,r,http.StatusServiceUnavailable,nornicdb.ErrClosed,ErrServiceUnavailable)
    return true
}