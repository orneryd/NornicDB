package cypher

import "context"

// IsClosing reports whether the owner has sealed provider admission. Protocol
// adapters use it to keep shutdown errors out of normal provider-failure fallback.
func (b *QueryEmbedderBinding) IsClosing() bool {
    return b != nil && b.closing != nil && b.closing()
}

// LoadForUse captures the same publication as Load, with provider-operation
// admission. A lease ends before a query emits results or invokes caller code.
func (b *QueryEmbedderBinding) LoadForUse() QueryEmbedder {
    if state:=b.snapshot(); state!=nil { return state.forUse() }; return nil
}
func (s *queryEmbedderState) forUse() QueryEmbedder {
    if s.guarded!=nil {return s.guarded}; return s.embedder
}
func (b *QueryEmbedderBinding) guard(provider QueryEmbedder) QueryEmbedder {
    if provider==nil || b.beginUse==nil {return provider}
    g:=&lifetimeQueryEmbedder{provider:provider,binding:b}
    // Metadata is immutable for a publication. Capture it while its installer
    // owns the provider, so later metadata reads need no model access or lease.
    if named,ok:=provider.(interface{Model()string});ok {g.model=named.Model()}
    if sized,ok:=provider.(interface{Dimensions()int});ok {g.dimensions=sized.Dimensions()}
    return g
}

type lifetimeQueryEmbedder struct {
    provider QueryEmbedder
    binding *QueryEmbedderBinding
    model string
    dimensions int
}
func(g *lifetimeQueryEmbedder) Model()string{return g.model}
func(g *lifetimeQueryEmbedder) Dimensions()int{return g.dimensions}
func(g *lifetimeQueryEmbedder) Embed(ctx context.Context,text string)([]float32,error){
    ctx,finish,err:=g.binding.BeginUse(ctx);if err!=nil{return nil,err};defer finish()
    return g.provider.Embed(ctx,text)
}
func(g *lifetimeQueryEmbedder) EmbedWithInputType(ctx context.Context,text,inputType string)([]float32,error){
    ctx,finish,err:=g.binding.BeginUse(ctx);if err!=nil{return nil,err};defer finish()
    if typed,ok:=g.provider.(typedQueryEmbedder);ok{return typed.EmbedWithInputType(ctx,text,inputType)}
    return g.provider.Embed(ctx,text)
}
func(g *lifetimeQueryEmbedder) ChunkText(text string,maxTokens,overlap int)([]string,error){
    _,finish,err:=g.binding.BeginUse(context.Background());if err!=nil{return nil,err};defer finish()
    return g.provider.ChunkText(text,maxTokens,overlap)
}