
WITH $payload AS payload, $keys AS keys
CALL (keys) {
  UNWIND keys AS each
  WITH DISTINCT each AS thing
  RETURN count(*) AS things
}
RETURN things
