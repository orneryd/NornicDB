
WITH $payload AS payload, $keys AS keys
CALL (payload, keys) {
  UNWIND keys AS each
  WITH each AS thing, count(*) AS occurrences
  RETURN count(*) AS things
}
RETURN things
